--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.3
-- Dumped by pg_dump version 9.6.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO test;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO test;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO test;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO test;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO test;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO test;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO test;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO test;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO test;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO test;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO test;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO test;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO test;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO test;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO test;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO test;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO test;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO test;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO test;

--
-- Name: overwork_overs; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE overwork_overs (
    id integer NOT NULL,
    reg_date timestamp with time zone NOT NULL,
    start_date date NOT NULL,
    "interval" integer NOT NULL,
    status character varying(100) NOT NULL,
    comment character varying(512),
    person_id integer,
    is_over boolean NOT NULL,
    kind character varying(42) NOT NULL
);


ALTER TABLE overwork_overs OWNER TO test;

--
-- Name: overwork_overs_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE overwork_overs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE overwork_overs_id_seq OWNER TO test;

--
-- Name: overwork_overs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE overwork_overs_id_seq OWNED BY overwork_overs.id;


--
-- Name: overwork_person; Type: TABLE; Schema: public; Owner: test
--

CREATE TABLE overwork_person (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    is_manager boolean NOT NULL,
    login character varying(200) NOT NULL,
    email character varying(200) NOT NULL
);


ALTER TABLE overwork_person OWNER TO test;

--
-- Name: overwork_person_id_seq; Type: SEQUENCE; Schema: public; Owner: test
--

CREATE SEQUENCE overwork_person_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE overwork_person_id_seq OWNER TO test;

--
-- Name: overwork_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: test
--

ALTER SEQUENCE overwork_person_id_seq OWNED BY overwork_person.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: overwork_overs id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY overwork_overs ALTER COLUMN id SET DEFAULT nextval('overwork_overs_id_seq'::regclass);


--
-- Name: overwork_person id; Type: DEFAULT; Schema: public; Owner: test
--

ALTER TABLE ONLY overwork_person ALTER COLUMN id SET DEFAULT nextval('overwork_person_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: test
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: test
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: test
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add person	1	add_person
2	Can change person	1	change_person
3	Can delete person	1	delete_person
4	Can add overs	2	add_overs
5	Can change overs	2	change_overs
6	Can delete overs	2	delete_overs
7	Can add log entry	3	add_logentry
8	Can change log entry	3	change_logentry
9	Can delete log entry	3	delete_logentry
10	Can add group	4	add_group
11	Can change group	4	change_group
12	Can delete group	4	delete_group
13	Can add permission	5	add_permission
14	Can change permission	5	change_permission
15	Can delete permission	5	delete_permission
16	Can add user	6	add_user
17	Can change user	6	change_user
18	Can delete user	6	delete_user
19	Can add content type	7	add_contenttype
20	Can change content type	7	change_contenttype
21	Can delete content type	7	delete_contenttype
22	Can add session	8	add_session
23	Can change session	8	change_session
24	Can delete session	8	delete_session
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('auth_permission_id_seq', 24, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: test
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
6	pbkdf2_sha256$36000$uOd19XpC30zV$VC8sdRU/pyK05VQqEgJ60QNqRdhsMFinO92Gs58PiZQ=	2018-04-20 11:01:03.40768+03	f	ObleukhovAA	Облеухов	Антон Алексеевич	ObleukhovAA@mosreg.ru	f	t	2017-05-29 17:50:23.168061+03
20	pbkdf2_sha256$36000$rFKjkh0givIA$XO3POmASwNGNIQHPNuIOfkjZGw8iXmGnzXqS+nIeKpo=	2018-03-19 10:59:31.192588+03	f	RozhkovVV	Влад	Рожков	RozhkovVV@mosreg.ru	f	t	2017-12-11 15:52:05.830134+03
15	pbkdf2_sha256$36000$natZ1kHw47Pe$MeegcXAveCPEUtKjw1/8RnOC7fKRMqwkuF9drUPLBuM=	2018-04-26 08:40:34.887988+03	f	KonovalovIA	Илья Андреевич	Коновалов	KonovalovIA@mosreg.ru	f	t	2017-09-04 08:50:07.4677+03
11	pbkdf2_sha256$36000$H6Uf9Cmt7LEe$wx6pd9DBareVnGmvag0K9rf1L+a+OkAc0klKZlKQKsg=	2018-04-27 17:16:22.72695+03	f	DobryninSA	Добрынин	Сергей Алексеевич	DobryninSA@mosreg.ru	f	t	2017-09-01 16:52:49.168656+03
1	pbkdf2_sha256$36000$gHiel3DqJ4DA$TdI5oWV5Xjtt5oItjGsH8WU/fxTpWZS+fPbpivO18CM=	2017-09-05 10:27:21.974443+03	t	admin				t	t	2017-05-22 17:24:38.557786+03
19	pbkdf2_sha256$36000$OLFtFmq452Qa$qlV/qmRrYukGSPYqguHxdKBmKywtoc3xAOZU92YDH1g=	2018-04-28 14:18:20.160632+03	f	lebedevim	Илья	Лебедев	lebedevim@mosreg.ru	f	t	2017-11-29 09:51:09.40521+03
18	pbkdf2_sha256$36000$WpZwAFwCcuCB$q4TmZgZH2ibSM+HvVU0s2R7OtUBf+xmQIqN9TT1NV64=	2018-05-04 10:28:37.193234+03	f	zhuravlevrv	Роман	Журавлев	zhuravlevrv@mosreg.ru	f	t	2017-09-11 11:38:45.771986+03
2	pbkdf2_sha256$36000$QhV24V401Y94$FRgGsyNNAv8Al+ECEw08c0DXgbpl1XHl5cYjNaJbP0s=	2017-11-28 15:47:26.109427+03	f	manager	Руководитель		belovmm@mosreg.ru	t	t	2017-05-22 17:25:48+03
12	pbkdf2_sha256$36000$FlG5Jg2AWYrL$8s4vFXc0G4Omm7I541RNEbazkOqCUZCbSCIbI6hptAg=	2017-09-01 16:54:39.78232+03	f	KabanovRE	Кабанов	Ренат Евгеньевич	KabanovRE@mosreg.ru	f	t	2017-09-01 16:54:39.661997+03
13	pbkdf2_sha256$36000$sXtChhytDTGx$cqjl5xgvDL6dFJx5b+o+OUEpPcrKfBHGZDmdfCLgG3s=	2018-05-10 09:56:34.796732+03	f	Larionov	Павел	Ларионов	larionovpo@mosreg.ru	f	t	2017-09-01 16:57:06.558313+03
17	pbkdf2_sha256$36000$PYPjRDK0souI$4A3UKY+755lKS6MMhailrKSeqGGuhs++A5LPdX1YGko=	2018-05-10 14:09:14.991017+03	f	BelovANVlA	Белов	Андрей Владимирович	BelovANVlA@mosreg.ru	f	t	2017-09-07 10:03:12.379555+03
9	pbkdf2_sha256$36000$U68FlSw0GMNL$XcZmDSsoWfLoO1X0vR1eBwwcyik3J5nlZvD7uNvcDsk=	2018-05-10 14:26:24.293309+03	f	MironovIUIU	Миронов	Юрий Юрьевич	MironovIUIU@mosreg.ru	f	t	2017-09-01 10:43:51.119318+03
14	pbkdf2_sha256$36000$JQZp7nin3Fr0$MFuait7c2fvvl3bWeZJTdsxyPI8OsrzI3UKlVKrfCqs=	2018-05-14 09:56:54.09259+03	f	OsipkovAS	Осипков	Андрей Сергеевич	OsipkovAS@mosreg.ru	f	t	2017-09-04 08:46:25.412329+03
8	pbkdf2_sha256$36000$ZVvvVk18tqPg$N+Fj0CjFcSzDkiS1peCes3LDfWmgV8hAdCoNhzaGdwc=	2018-05-16 16:24:12.241834+03	f	BelovMM	Михаил	Белов	BelovMM@mosreg.ru	t	t	2017-08-31 11:11:42+03
10	pbkdf2_sha256$36000$5o2rMQrX2ArD$9NME30dzxXUWT9tn7N6iut/Vu8qSNtXd+uyVhjKNQcM=	2018-04-06 14:10:21.068588+03	f	lavruhinae	Андрей	Лаврухин	lavruhinae@mosreg.ru	f	t	2017-09-01 16:51:40.352297+03
4	pbkdf2_sha256$36000$9NV1eSOXQc1L$IPwUItMhiaq+G/teg0Umyz9N+VZZSjxkZwU9Ojw3Dp0=	2018-01-25 16:22:38.553109+03	f	tikhomirovsvl	Станислав	Тихомиров	TikhomirovSVl@mosreg.ru	f	t	2017-05-26 18:03:00.837072+03
16	pbkdf2_sha256$36000$BVZqYPvTxiQ2$VsTixOh8W+7BWR0ytGxvcofLaIj5TYmFuI4hLT8+Lq0=	2018-01-31 09:59:07.049523+03	f	OsokinRL	Роман	Осокин	OsokinRL@mosreg.ru	f	t	2017-09-05 09:51:13.628836+03
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: test
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('auth_user_id_seq', 20, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: test
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: test
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2017-05-22 17:30:03.651183+03	2	manager	2	[{"changed": {"fields": ["email", "is_staff"]}}]	6	1
2	2017-08-31 10:32:37.933928+03	7	anon	3		6	1
3	2017-08-31 10:32:37.972795+03	3	testuser	3		6	1
4	2017-08-31 10:33:35.044995+03	6	anon #  (-)	3		1	1
5	2017-08-31 10:33:35.047696+03	2	testuser # tikhomirovsvl@mosreg.ru (-)	3		1	1
6	2017-08-31 11:14:36.313658+03	7	BelovMM # BelovMM@mosreg.ru (+)	2	[{"changed": {"fields": ["is_manager"]}}]	1	1
7	2017-08-31 11:15:48.065496+03	8	BelovMM	2	[{"changed": {"fields": ["is_staff", "last_login"]}}]	6	1
8	2017-09-05 10:27:48.860442+03	4	osokinrl # 1 (-)	3		1	1
9	2017-09-05 10:27:49.692637+03	5	osokinrl	3		6	1
10	2017-09-11 12:22:26.203808+03	148	2017.09.11 Registred  10 minutes Роман Журавлев (DN)	1	[{"added": {}}]	2	1
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 10, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: test
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	overwork	person
2	overwork	overs
3	admin	logentry
4	auth	group
5	auth	permission
6	auth	user
7	contenttypes	contenttype
8	sessions	session
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('django_content_type_id_seq', 8, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: test
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2017-05-22 12:41:11.220296+03
2	auth	0001_initial	2017-05-22 12:41:11.408931+03
3	admin	0001_initial	2017-05-22 12:41:11.470455+03
4	admin	0002_logentry_remove_auto_add	2017-05-22 12:41:11.504657+03
5	contenttypes	0002_remove_content_type_name	2017-05-22 12:41:11.558513+03
6	auth	0002_alter_permission_name_max_length	2017-05-22 12:41:11.574438+03
7	auth	0003_alter_user_email_max_length	2017-05-22 12:41:11.597657+03
8	auth	0004_alter_user_username_opts	2017-05-22 12:41:11.619889+03
9	auth	0005_alter_user_last_login_null	2017-05-22 12:41:11.650342+03
10	auth	0006_require_contenttypes_0002	2017-05-22 12:41:11.662547+03
11	auth	0007_alter_validators_add_error_messages	2017-05-22 12:41:11.68974+03
12	auth	0008_alter_user_username_max_length	2017-05-22 12:41:11.743961+03
13	overwork	0001_initial	2017-05-22 12:41:11.774056+03
14	overwork	0002_overs	2017-05-22 12:41:11.817906+03
15	overwork	0003_overs_person	2017-05-22 12:41:11.865593+03
16	overwork	0004_auto_20170510_0917	2017-05-22 12:41:11.88457+03
17	overwork	0005_overs_is_over	2017-05-22 12:41:11.910015+03
18	overwork	0006_auto_20170511_0941	2017-05-22 12:41:11.920983+03
19	overwork	0007_auto_20170511_1356	2017-05-22 12:41:11.94626+03
20	overwork	0008_auto_20170511_1357	2017-05-22 12:41:11.961058+03
21	overwork	0009_auto_20170516_0707	2017-05-22 12:41:12.010091+03
22	sessions	0001_initial	2017-05-22 12:41:12.033761+03
23	overwork	0010_person_email	2017-05-23 11:59:31.213892+03
24	overwork	0011_overs_kind	2017-11-16 15:25:16.789884+03
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('django_migrations_id_seq', 24, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: test
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
5zg56vebgkz9sznkadiq5b60i017632x	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2017-09-15 16:51:40.484282+03
jrtpiy9pwx4iasz8xeizarz8zcilvova	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2017-09-15 16:52:49.289124+03
3uhws1vy8n6u8n9bb839e7ne4u0px7m1	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2017-09-15 16:57:06.695143+03
rrl3x69jmgvtoe78tjpq7ianbpig9lx5	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2017-09-18 08:46:25.539635+03
01cbb2lh2h6ot1iym7xdj6bv2xvsaigg	MjQwYzljMjY1OGZmMjc5ODUyZTQxZDllM2VhMDMwMWJiMDQ0MzU0Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjAyYjgyOWMwNjcxNzI2ODA3ZDA4ZjAzZDAzMGY4NTM1YzJhMTZlODEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNiJ9	2017-09-19 09:51:13.751361+03
z4l4yzzi2cx8n8twsdx39etluqnpctpf	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2017-09-21 10:03:12.504292+03
sxd2m9rn3uj7978ieqjdjnn9upyr7kvl	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2017-09-25 11:38:45.894891+03
bu9riuqdcnpezpipqzw5nqlarzubas5y	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2017-09-25 11:39:38.242892+03
d1m5bry5jzkiwzt0ls2myktiipmoqlm2	MTliMTk2Mzk5MTMyZmZkMzhjNmI4MjRmMmNhMGIyMWMxOTgwMGZiODp7Il9hdXRoX3VzZXJfaGFzaCI6ImE3YTdmMDc0MTlmYmE3YmFiN2U2OGM4MGY4MWI5MWU2NmZhYmNhMmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2017-06-06 12:24:23.597989+03
ootep2vatfz6im7jrk36pw2hni233ut1	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-09-29 09:19:21.544201+03
g70gckjvgn24t6d5zbzx75puq9mzgkvn	NmRjMTExNjExNDNhNjJlM2YzMTZlNzNjNzVjNDliOTYxYWY0OTYzYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjVhM2UxOTY4ZTE0MjFkMzYwODM1OWRlM2M4M2FjNmM4M2EyZTk1NGEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI0In0=	2017-09-29 09:21:57.196149+03
heehks9l0m3sxq9ddvdp76ff5ed45pjd	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2017-10-03 18:17:02.256877+03
kfgd7qqz8e5fi9e7t4dklkkyieunj1y0	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2017-10-04 11:25:15.185086+03
s9t3m6enphxfb9z338482c9tiqf0r9ha	YWY5Nzc1NTVlZGQwNmIzOWI2YzRiY2YxMzhhYjhiMzlkM2I1NmNjMDp7Il9hdXRoX3VzZXJfaGFzaCI6IjI0YjE2MWFhMjYzOGQ2Mjk0YTE4MDIwMTk1NGZmY2E0Y2E1N2RlZmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI1In0=	2017-06-12 15:05:54.742796+03
r69r4o26g4rjt907oeie6ccoxm7e492d	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2017-10-04 12:01:52.529538+03
7sdg3ex56cuk9c03rhvou8xg2r876cyy	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2017-10-05 08:38:47.996306+03
f8rrav4pl956ht8nt4w0qx9sjifhkgtr	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2017-06-12 17:50:23.31626+03
uhf5ww4ie8etw73bg39iyn7o7l5aqclb	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2017-10-05 11:34:54.398366+03
t6uljjfrjr93omp1veibbd46u5cvvyn5	MWVkY2I5MzJiNTQzY2ZkYmY3ZTlkNDJhNTcxYTNhMDI0MzgyY2NjZjp7Il9hdXRoX3VzZXJfaGFzaCI6IjAzMjU0OGYyNDAzMjlmMDU0YjNmMTg2ZDZmY2I5YTJlYzVmOWRlNWUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI3In0=	2017-06-13 18:09:37.918785+03
1li3x4ebf5ewc0kxhx8lj3n7zumsskld	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2017-07-26 09:23:01.659639+03
lrn73aby70ygzw642ta4hutw7nr3uuem	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2017-09-11 14:46:22.362948+03
3o1ut0lhxdaa36h45u1dh2fvnguhr67g	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-09-14 11:15:45.811644+03
6gz9vu1wq0o9sw5z1tn56m3pz5454v4h	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2017-09-15 10:43:51.246029+03
lxpxzahtovctaekmpb0wkk6lq3qr9nnq	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-10-13 11:19:13.268609+03
4ofv5wtg6dznxwzhf4aublytooc4j0bo	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2017-12-01 14:25:23.555443+03
36q9nwsgzkvt919d5gh0u28vu5ea6g84	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-01-11 09:23:04.385119+03
e8zv31p92vgck3gxcrvgkoom1ij6f3dp	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-03-12 17:53:46.483933+03
6uitegp2q3tymoarselmr7u0irm1zuk0	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2018-03-14 08:36:48.996537+03
rd5vt8i9stzhohv7scq1ahzr2dq0ta6v	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2018-05-04 11:01:03.409601+03
utdqze0llgeknega9ldn7ldif42xvfex	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2017-10-16 11:27:00.935108+03
g8txcw952q7micwgnwq32t1qkqtto6hx	MjQwYzljMjY1OGZmMjc5ODUyZTQxZDllM2VhMDMwMWJiMDQ0MzU0Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjAyYjgyOWMwNjcxNzI2ODA3ZDA4ZjAzZDAzMGY4NTM1YzJhMTZlODEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNiJ9	2017-12-04 09:22:47.442878+03
99a6has62s08l8xam5lfr6seogpsnkc5	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-03-15 22:50:09.442609+03
5wdnlsoo28i7qc6rlb0bwaxrf6ubgssu	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-01-21 18:07:49.262885+03
vphlqmgebi5i5zhko33b08ihozr6sqrz	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-05-08 10:24:38.171019+03
fe84fud7n4ipknpgkkksp8yhmdzis5pc	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-05-30 16:24:12.257308+03
73ir4wb2p03veejc1xebd839prl9zxoj	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2017-12-05 13:24:59.982379+03
yt2tspc6np1f47bj72kkom4iqr29pzr6	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-03-16 08:15:35.597144+03
1zth2oi5xtysr3wex1faqb499h0u2ua7	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-01-23 14:18:53.39632+03
ycedctgj2kbzdd8h7sodrwd31ju03vrj	NTQzMDNmNjlhYWQyZGRhM2E5ZTg2ZDJhMTc3NzQ3ZmY3ZWQ2NzczZjp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5ODQwOWRmZjgwNmY5NmM0OWIwYjRiZWQyMzJkOTkzYjk2ZGQ5NGQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyMCJ9	2018-03-13 16:58:00.580153+03
0fjidhoa3sy832zam7ca1ag4q8kxbw7t	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-05-10 08:40:34.889751+03
jw6w2roqc51qftoxxwzu5bp1123cqwd6	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2017-10-17 14:20:35.793869+03
l3m0nmlkkdu4kwncdp1amzp3cxaswdtg	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2017-12-05 19:07:06.891371+03
tvzstox3rppac7oe1v553wzkb0xrfp1k	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2018-03-20 17:36:17.916863+03
22ygfws97mfkf819a8a1ssm7ow0033be	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-01-25 12:30:41.738823+03
8db28962708ge7ncu6g1tu3qo7utnyvh	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-05-11 17:16:22.731074+03
i4n6u654v036nkka49gtvuosopwltpmd	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2017-10-19 14:36:45.958419+03
tq6r4mc3if0gbrjval1mmtn994wlsp3u	MjQwYzljMjY1OGZmMjc5ODUyZTQxZDllM2VhMDMwMWJiMDQ0MzU0Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjAyYjgyOWMwNjcxNzI2ODA3ZDA4ZjAzZDAzMGY4NTM1YzJhMTZlODEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNiJ9	2017-12-11 17:08:28.365577+03
dsgzc0tl0c6a3qo3720c5moufcocta42	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-03-20 18:15:00.864916+03
anqtvcusvh6idnq5l0vnivr4zb51dz15	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-01-25 12:31:46.466171+03
5nngeb18j07qbilkfxrb58ttyoz8rj2w	NWQ5OWEyNmEyNmM1ZTI4OWRiMWI1ZDIxMjlmNmE1ZDIyNzQwYTYyMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjA3YTZiZTI5NDNhMTAzZmE2ZDNhY2E4NjllZGUwODE5YmFhZmZiNDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOSJ9	2018-05-12 14:18:20.16253+03
5r15rh3myxtv2no5b16s8wnebx7mza6z	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2018-03-22 12:36:18.033946+03
1ms0csd9y4s0ygmoft8l0upbntxzyt1g	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2018-01-25 12:59:59.23133+03
qi45yn7esjbjts29bdu5gb8zz6yddb5i	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2018-05-18 10:28:37.195435+03
4aqf25fhamzb6lfdnterz5e7m9oxw3ym	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2017-10-27 10:27:13.931786+03
m791d9nn73k1s7bq2185eunjqsm3pyzz	MTliMTk2Mzk5MTMyZmZkMzhjNmI4MjRmMmNhMGIyMWMxOTgwMGZiODp7Il9hdXRoX3VzZXJfaGFzaCI6ImE3YTdmMDc0MTlmYmE3YmFiN2U2OGM4MGY4MWI5MWU2NmZhYmNhMmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2017-12-12 15:47:26.111645+03
xeu7mgr1noasq0z6klku7kmkse2j74pm	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-03-28 09:08:27.0238+03
a0l4nvudcry128d7y533wfw1ya3a63xg	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2018-01-26 10:27:49.611178+03
fiw2kigoidlke57tsccukafgoiaflczx	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-05-22 17:33:15.17837+03
nlvwkxk49hg6j7agpf75ibcu0vuye6oj	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-10-27 11:18:18.281808+03
ttsfty4ut28o2uh0c91hdhdsgmatw07t	NWQ5OWEyNmEyNmM1ZTI4OWRiMWI1ZDIxMjlmNmE1ZDIyNzQwYTYyMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjA3YTZiZTI5NDNhMTAzZmE2ZDNhY2E4NjllZGUwODE5YmFhZmZiNDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOSJ9	2017-12-13 09:51:09.549716+03
1wphftwphso4lu6jfzo5xg9jmxluw4m0	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2018-03-28 10:26:34.683274+03
4xjf03o5xf61ukc8lztw7a4jc3k24zd2	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2018-01-26 14:44:46.661103+03
l8aohept0dcu1nwk7vian6dqmvhhvt76	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2018-05-24 09:56:34.799133+03
p9c9693f9slz58f6qtnklpcfx4xwjmx7	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2017-10-27 18:10:07.098534+03
51add3lg4pcccdsgls3ciwk9sr3o8y27	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-12-13 12:39:42.831894+03
stkhw4x4fb0gvui1c3an1r4hh7ir9iky	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2018-03-29 09:46:42.259015+03
b8to272egv3u7siyuts8k42o00kiv1o8	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2018-01-30 14:46:26.440336+03
cimht52qwck4yus8nrrk2ayd84656jzt	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2018-05-24 14:09:14.993364+03
jple57hnx3ligfvcvf3tnnrx74esvrhp	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2017-10-28 13:31:42.144474+03
1rnd4idcqiu930efafpdo18n0279913q	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2018-03-30 14:38:09.476531+03
ff13uebgmjdgx8ewype174cuc4ibzv0u	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2018-02-01 09:47:39.069196+03
f7eye7nip9afg5q41vgu5t9rmuboomqs	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-05-24 14:26:24.295801+03
5kjinjg0exnk1avzahrm5lzrtom8wcwx	NmRjMTExNjExNDNhNjJlM2YzMTZlNzNjNzVjNDliOTYxYWY0OTYzYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjVhM2UxOTY4ZTE0MjFkMzYwODM1OWRlM2M4M2FjNmM4M2EyZTk1NGEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI0In0=	2017-10-30 09:11:50.142681+03
ul2pc66w8rjl4eyuak75ylmlkyj9f7pg	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2017-12-13 15:44:52.64329+03
i55ftdrpparvbmiuljothy9izchrecdu	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-04-02 08:13:27.552501+03
9wbionc6xninh20ranv2i77tn5qkjftd	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-02-05 10:23:56.411567+03
v6mw64lje7p9ad9fey1ye612jy1wpd6i	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2018-05-28 09:56:54.094892+03
byrys7ll8r1nbkpu7sp9ghrrvkp5et83	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-10-30 15:35:57.290287+03
dqam9ohy9m9nusnwbgbxcq5r7vk3jbtr	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2017-12-18 11:39:45.558992+03
jxhc0bry7grcfrv0s9ndwtns1x81gyj7	NTQzMDNmNjlhYWQyZGRhM2E5ZTg2ZDJhMTc3NzQ3ZmY3ZWQ2NzczZjp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5ODQwOWRmZjgwNmY5NmM0OWIwYjRiZWQyMzJkOTkzYjk2ZGQ5NGQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyMCJ9	2018-04-02 10:59:31.196264+03
q9ayeg2p6sy2mqeq1ej679dzbxzd3nqt	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-02-05 10:26:34.586351+03
tk97ok4wgux8pt2uulxqyblbokzuupvm	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2017-12-19 15:24:29.310928+03
brh68qt9wl4cslx9eimenzkkxzxdttgp	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-04-04 21:39:23.389793+03
krt0itkvokwloisghf2zqzc69p157kka	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2017-10-31 10:01:16.03096+03
dry08vfhavuw86xu0zujizyk0enykxag	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2017-12-20 10:13:33.594661+03
wkruzx2qojr93eswm7phg4p3b1jqqw4s	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-04-05 09:51:43.476186+03
cjy3x11a1yg37izqfl3jmu65a2frq7eb	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-02-08 15:37:00.137768+03
kkxvoiiqlqnqbiszv1nlzteaz3s8mtbo	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2017-11-01 14:11:03.007921+03
9rw9ostlka18i53yv470fgl0l5uclnel	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2017-12-20 10:13:37.732134+03
by5tpgoms2rg2e30mbsnqa8futps8wq0	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2018-04-08 13:20:45.90692+03
5l7ilrjv333er7fj4dalpuye5it3bg45	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2018-02-08 16:15:45.036725+03
iooa6zl61dp4oiy0mhnk2rn1ihb41rg0	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-11-06 11:29:15.896957+03
jb71t4vks35trxh20gaswnr1trrte7he	NTQzMDNmNjlhYWQyZGRhM2E5ZTg2ZDJhMTc3NzQ3ZmY3ZWQ2NzczZjp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5ODQwOWRmZjgwNmY5NmM0OWIwYjRiZWQyMzJkOTkzYjk2ZGQ5NGQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyMCJ9	2017-12-25 15:52:05.979266+03
mq8bq75yo55yojw64uunpm2rc8ayudgn	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-04-09 09:20:32.401771+03
yigplxvrhd8569epeha1fwbjqw85hk8y	NmRjMTExNjExNDNhNjJlM2YzMTZlNzNjNzVjNDliOTYxYWY0OTYzYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjVhM2UxOTY4ZTE0MjFkMzYwODM1OWRlM2M4M2FjNmM4M2EyZTk1NGEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI0In0=	2018-02-08 16:22:38.558588+03
fx96f71mhrxj3ybjdxbamapgqz1b9e5n	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2017-11-07 10:47:26.987556+03
lo4gtvavmbmmsgw7jfnkyzfirs2me4pe	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2017-12-26 13:06:08.017876+03
v1agi6geqpqwmj4hmfk6ulhnwj8hx26x	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2018-04-11 16:59:27.536504+03
cmqlwq5kxxdf4st4c95uthtov3vsydo5	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2018-02-09 10:33:28.098941+03
x6h5yjdvqhukyh6miqci5kri3agr1gig	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2017-11-08 12:16:13.508372+03
gy6i6vhqwqv6g3v94wyg0jbmff7cuwo2	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2017-12-26 17:55:35.38145+03
m45bnbi9vm8qhro64kahh6kzbu8ceqtv	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2018-04-16 09:38:39.245188+03
7frwbn3736c5su8mb3r925m0gwaoicp8	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2017-11-14 08:28:58.61531+03
l4yrmm6c3qf3rmj7ncn720742e1k6u18	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2017-12-28 09:09:59.279213+03
sfzulp19i52q6pwaj0rhp8jmtl3tq7f5	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-04-16 13:00:23.552494+03
a28udqv3e7sqh0e9ke77arni7u9th67h	MjQwYzljMjY1OGZmMjc5ODUyZTQxZDllM2VhMDMwMWJiMDQ0MzU0Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjAyYjgyOWMwNjcxNzI2ODA3ZDA4ZjAzZDAzMGY4NTM1YzJhMTZlODEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNiJ9	2018-02-14 09:59:07.051786+03
ehukolku0j1gil5trcp6tedftem0l1rh	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-12-28 09:14:46.282735+03
izufucfqgvt2mmpj58qxvxr7kw1uq6e5	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2018-04-19 18:59:28.205009+03
nwzue7e2hp1xte1ihg3uww7v11kju8ro	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-02-14 20:57:48.316964+03
z4jmlj652jy6f96n8nnpbfn0mt99z6ox	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-11-14 14:34:03.158372+03
btc7eptv4qjm8xo8dztrju7oepjxaljz	MjQwYzljMjY1OGZmMjc5ODUyZTQxZDllM2VhMDMwMWJiMDQ0MzU0Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjAyYjgyOWMwNjcxNzI2ODA3ZDA4ZjAzZDAzMGY4NTM1YzJhMTZlODEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNiJ9	2017-12-28 10:08:12.587328+03
0rl9s8jzt458wyda26bnupwmc6mrcwf8	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2018-04-19 19:00:14.439293+03
7me77fr2y2gq64lgu0e6487ercx3omrq	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-02-15 09:49:32.672595+03
j4n8hpqbloctlzjq3cewlhj5zi5r6n6r	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2017-11-14 20:30:40.040116+03
i8tpt5qtfur382ynztoy7ozhaq2j04co	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2017-12-29 12:23:44.698998+03
ih08bvj5cycr330umbzdrxkojkz41o4n	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2018-04-20 14:10:21.070842+03
vxc1dbg5kmyrfkpebc7zxtb9rn1qxf45	MjA0MGY3ZWRhMTc3MGE4ZTcyZTczMTgyNTkxNGZhZmM2MDI0MzE4Nzp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjFiYTc5NzU0Mzg2MjYyNmUwZmMyZmFlNGQ1MTNjNDdiNWM3MzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMCJ9	2018-02-26 11:26:20.796921+03
n3cky4rw0lsaktc8q6e1idoys6mrtx0w	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2017-11-27 14:13:30.002798+03
vadja17dfweybn9d295lc65ys91lg8uj	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-01-05 08:45:15.8624+03
kbjavygwv3ns2mm1qh5av6pr8fd8wsod	NWQ5OWEyNmEyNmM1ZTI4OWRiMWI1ZDIxMjlmNmE1ZDIyNzQwYTYyMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjA3YTZiZTI5NDNhMTAzZmE2ZDNhY2E4NjllZGUwODE5YmFhZmZiNDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOSJ9	2018-04-20 16:35:26.505809+03
zjkugbybukya6fcp10grh2qm3bp8jjjw	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-02-26 11:32:43.326442+03
2cqo2omhvb17mtmebgb9armu2vbseucs	MjQwYzljMjY1OGZmMjc5ODUyZTQxZDllM2VhMDMwMWJiMDQ0MzU0Mzp7Il9hdXRoX3VzZXJfaGFzaCI6IjAyYjgyOWMwNjcxNzI2ODA3ZDA4ZjAzZDAzMGY4NTM1YzJhMTZlODEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNiJ9	2017-11-29 09:45:55.87802+03
gmdlcb1flqyr5to6i766ni6sz8yxjqhh	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-01-09 09:17:50.464253+03
r8g586td23y0ygpbq6eo5npwswjz5ji4	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2018-04-23 10:58:31.574595+03
8qhb9flhb8s5twwn28xuau2f0zss5aev	YThhMjVkMjkyODlhZmRkM2M0NWM2ODAzYjViMjhlZjYxZTMxNjQwNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjJhNWMwOTUyZTg1YjVmMTgzZmYxMGUyNDg2MTkxNDc1Yjk1YjEyMDUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI4In0=	2017-11-29 09:50:18.27747+03
pnh0pbm61lv4h5lf5lyeh7omlqkq8diz	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2018-01-09 11:19:59.918157+03
ie0fh6jyoe4473daaazx60uw3r0kdpml	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-04-23 11:59:23.570882+03
vhh62re3ncmgpuchnb27z9qs5by8rprx	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2018-02-28 09:31:08.013256+03
dy3a50lbtnsd8tijb4swub2v6qgvrnqv	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2017-11-29 10:01:14.52158+03
d080j8jj54qytedpvpttmhdtgnwgceng	MTQ2ZjJkMzkzMjY2MzNkMjhhZjgxNmJlMTZiY2E1NWE5MGIwNjNlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImQ0M2JiODQxZjI4Y2ZjMDYwMWJjNmZiMzg4MDBiZTVmMGY4YTc2OGIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNyJ9	2018-01-09 14:19:57.446206+03
whgvu4lfvi8m2f2feu3lhrjkgmg3d5k0	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-04-26 18:22:33.350067+03
0fz7bahhonqv8qousc32ty6gr76kzu7k	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2018-02-28 10:00:49.478644+03
eetmwlzmqdsph9l80or5tz36vdk10883	NGFkNWQwODg1OTA4NjQzYmU4ZDVlNmQ4NGFlNTEzZWU1YmJjNTgwOTp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5NDQ0ZDQ3ZGUxZWFlNWI0Yzk3NjAwYmMxOGQzNjc2YzJlNjQ1MGUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMyJ9	2018-01-10 07:58:45.727975+03
41idufxskm9t550s96apf7j6fhn0uayp	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2018-04-28 21:59:47.870059+03
4ddy9bmb8iyrh1bjfcaruq5dk5tjsnbq	NjBiNGFlOTYwOGMwMzg0MTJjYjYyOWJhY2I0YjZlZWRlM2M0MzRlODp7Il9hdXRoX3VzZXJfaGFzaCI6ImJjNWVmNDcwZmYxNWVlN2JmYTUwMmM0YzM3NTE2ODMyYThhMjNkMzciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNSJ9	2018-03-01 09:39:43.340853+03
87qpsgo8h6r7ugd941lbm22thpsp4lov	MTliMTk2Mzk5MTMyZmZkMzhjNmI4MjRmMmNhMGIyMWMxOTgwMGZiODp7Il9hdXRoX3VzZXJfaGFzaCI6ImE3YTdmMDc0MTlmYmE3YmFiN2U2OGM4MGY4MWI5MWU2NmZhYmNhMmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=	2017-11-30 15:27:44.919004+03
zjkaloduxitj9tr5lwdu1fxlunynx5kh	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2018-01-10 14:55:45.249831+03
5hofbtnne9ll5vgghp928ul0et4iuc8q	MWQzYmQyOTNlNTc5ZDNkNWNlOTEzOTU5MzE1ODk2ZjdjMTBmYzkyODp7Il9hdXRoX3VzZXJfaGFzaCI6ImRmNjA2NzBlZmNhMTFkNDZhYzgyYjU5N2Q3MGY3MWVjYTQ2OWI1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxNCJ9	2018-05-01 14:03:15.92867+03
m8ma51qi271ssxgig44yyjah877v8mi9	ODcwNGYzMzJhMjdmNzFjMGI2ZDhmYzI3OGM0Zjc5Y2U1OWQzYmEyYTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjlkMTM2MTcwOGVhZmRiNjRhMGUxMjczYmVkNzJhNDdkZWE4NGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxMSJ9	2018-03-05 20:16:13.818848+03
ve6rrmu0lh7ejm9juhho19mo4bc5zsf5	ZjEzMzVkODUwMDM0YWE3ZTQxZGQzZDljNmI1NjUzMWZmOGFhMWZlYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjBlMWE2M2RkYTEzZDk5OWU5NDc4MTNkNWFkMDUwMTAxNmM0ZWZmY2QiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=	2017-12-01 10:56:09.572021+03
rvk1gk8h1miiunjjbrszstuhsbyjnrab	NTQzMDNmNjlhYWQyZGRhM2E5ZTg2ZDJhMTc3NzQ3ZmY3ZWQ2NzczZjp7Il9hdXRoX3VzZXJfaGFzaCI6IjE5ODQwOWRmZjgwNmY5NmM0OWIwYjRiZWQyMzJkOTkzYjk2ZGQ5NGQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyMCJ9	2018-01-10 18:55:38.659942+03
ptjob0lpp8igrx1xjaroh6tevj5w6ilc	N2Y4ZDZhZDhiMmViZGYxMzBkN2RkZmI4NDg4YzQ5YTMxMTA5ZDZlMjp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhMDkyMzRlZmI0NjM2ODhkMDRhN2FlMDMwNTEwOWM0ODk2MjIzOGYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI5In0=	2018-05-02 10:21:08.557543+03
1vsgyed5xikywubrkmo0zm8hozpb2qyq	NDY0YjAwMDk1NmVlOTg5Y2VjNzc3NzMzZDc5MGRhNzIwNjZkODY3Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjRmMzkwOTUyMzkyMmUzZmU4Y2E1ZTY2NDQ3MTlkMjI5ZTI2MDFhMjQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxOCJ9	2018-03-12 17:48:58.218136+03
\.


--
-- Data for Name: overwork_overs; Type: TABLE DATA; Schema: public; Owner: test
--

COPY overwork_overs (id, reg_date, start_date, "interval", status, comment, person_id, is_over, kind) FROM stdin;
136	2017-09-06 18:03:53.979073+03	2017-09-06	60	A	LOD-1381	10	t	O
104	2017-08-31 10:10:20.334293+03	2017-08-30	60	A	Перезагрузка tomcat'ов и мониторинг	3	t	O
103	2017-08-31 09:55:39.457596+03	2017-08-30	60	A	Отладка тестирования по ГУДХ	5	t	O
102	2017-08-28 14:50:07.695422+03	2017-08-29	120	A	с 9 до 11	5	f	O
101	2017-08-28 14:46:56.311516+03	2017-07-21	360	A	Отгул в счет ранее отработанного времени	5	f	O
100	2017-07-12 09:23:54.772949+03	2017-07-12	240	A	В счет ранее отработанного времени.	5	f	O
106	2017-08-31 10:57:29.638737+03	2017-08-31	60	D	TEST	3	t	O
111	2017-09-01 10:47:25.423865+03	2017-09-01	720	A	-	8	t	O
110	2017-09-01 10:47:18.267472+03	2017-09-01	1440	A	-	8	t	O
109	2017-09-01 10:46:40.293708+03	2017-09-01	1410	A	-	8	f	O
108	2017-09-01 10:46:15.777697+03	2017-09-01	1440	A	-	8	f	O
107	2017-09-01 10:46:11.4689+03	2017-09-01	1440	A	-	8	f	O
112	2017-09-01 16:50:09.698185+03	2017-09-01	360	D	-	8	t	O
114	2017-09-01 16:52:48.774194+03	2017-09-01	360	A	-	8	f	O
113	2017-09-01 16:52:36.367327+03	2017-09-01	810	A	Перенос из гугл дока	9	t	O
116	2017-09-01 16:55:27.204507+03	2017-09-01	420	A	Перенесено из googledoc	11	f	O
115	2017-09-01 16:54:05.282871+03	2017-09-01	390	A	дельта из гуглодока	10	f	O
117	2017-09-01 16:56:22.952509+03	2017-09-01	420	A	Перенос из гуглдока	7	t	O
118	2017-09-01 17:00:43.465048+03	2017-09-01	1320	A	Перенос из гуглодока	12	f	O
119	2017-09-01 17:00:55.434138+03	2017-09-01	960	A	Перенос из гуглодока	12	t	O
143	2017-09-07 10:12:12.105528+03	2017-01-24	240	A	Релиз функционала ЕФТТ для охоты.	16	t	O
142	2017-09-07 10:11:18.833149+03	2017-03-29	120	A	-	16	f	O
141	2017-09-07 10:11:09.905884+03	2017-03-28	90	A	-	16	f	O
140	2017-09-07 10:10:39.544604+03	2017-03-27	240	A	-	16	f	O
132	2017-09-04 08:53:11.873364+03	2017-09-04	180	A	перенос из гугл-таблицы	14	t	O
131	2017-09-04 08:51:11.385292+03	2017-09-01	480	A	-	13	f	O
123	2017-09-04 08:49:08.252724+03	2017-08-24	120	A	-	13	f	O
121	2017-09-04 08:47:53.848828+03	2017-08-24	750	A	Перенос из файла	13	t	O
120	2017-09-04 08:47:27.327014+03	2017-08-24	1020	A	Перенос из файла	13	f	O
133	2017-09-04 14:34:27.705374+03	2017-09-07	240	A	c 14.00 до 18.00	5	f	O
135	2017-09-05 09:53:32.542489+03	2017-06-28	120	A	перенос из гугл-таблицы	15	f	O
134	2017-09-05 09:53:07.493295+03	2017-07-24	480	A	перенос из гугл-таблицы	15	f	O
139	2017-09-07 10:10:14.503983+03	2016-12-22	150	A	-	16	f	O
138	2017-09-07 10:09:54.95525+03	2016-11-17	60	A	-	16	f	O
137	2017-09-07 10:09:30.546985+03	2016-11-15	120	A	-	16	f	O
144	2017-09-07 10:41:01.486028+03	2017-08-11	120	A	Поход в МФЦ.	16	f	O
145	2017-09-07 17:58:24.974776+03	2017-09-07	60	A	Отработка долга	13	t	O
146	2017-09-11 11:17:38.161159+03	2017-09-11	120	A	-	10	f	O
149	2017-09-11 12:24:24.289074+03	2017-09-11	600	A	перенос сведений из гуглодока \t	17	f	O
150	2017-09-11 14:43:29.210213+03	2017-09-12	300	A	Нужно сдавать анализы и идти к врачу.	15	f	O
151	2017-09-11 16:31:18.145358+03	2017-09-08	60	A	отработка долга	13	t	O
152	2017-09-12 12:03:21.678135+03	2017-09-11	60	A	Отработка долга	17	t	O
153	2017-09-13 09:19:37.693716+03	2017-09-13	60	A	По 30 минут за 07.09 и 13.09	9	f	O
154	2017-09-14 19:29:39.36159+03	2017-09-14	60	A	Устранения ошибок связанных с выводом ветки LOD-1412	13	t	O
155	2017-09-15 09:22:55.948303+03	2017-09-14	60	A	18:00-19:00  STP-155 Окно приема заявок для внешних пользователей	3	t	O
156	2017-09-15 10:06:52.592817+03	2017-09-18	240	A	Суд. Часть 1.	16	f	O
157	2017-09-15 18:39:10.365534+03	2017-09-15	60	A	отработка долга	13	t	O
166	2017-10-03 14:21:29.014503+03	2017-10-02	120	A	Закрытие критичных обращений пользователей	17	t	O
158	2017-09-19 18:18:01.674625+03	2017-09-19	120	A	Отработка долга перенос авансового платежа на МПРУ LOD-1380	5	t	O
159	2017-09-20 11:25:52.260637+03	2017-09-20	300	A	Плохое самочувствие	9	f	O
160	2017-09-21 08:39:12.337161+03	2017-09-20	60	A	отработка долга	13	t	O
161	2017-09-21 11:35:20.125154+03	2017-09-21	150	A	Экспертиза квартиры.	16	f	O
162	2017-09-21 20:46:04.61336+03	2017-09-21	240	A	Вывод МО, МПРУ. Устранение ошибки на МПРУ с библиотекой six	13	t	O
163	2017-09-25 21:11:53.195583+03	2017-09-25	60	A	Вывод функционала получения заявки с портала через РЛДД на металлах	5	t	O
164	2017-09-27 18:10:07.975955+03	2017-09-27	60	A	отработка долга	13	t	O
165	2017-10-02 11:30:56.02107+03	2017-10-02	180	A	Хочу отгул с связи с болезнью и поездкой в Ярославль	14	f	O
97	2017-05-29 17:51:51.085852+03	2017-05-29	540	A	Суммарная переработка по итогу на 29.05.2017 из Google таблиц	5	t	O
167	2017-10-04 12:27:45.782225+03	2017-10-03	120	A	Закрытие критичных обращений пользователей	17	t	O
168	2017-10-05 14:53:32.996064+03	2017-10-05	120	A	-	10	f	O
169	2017-10-13 11:04:28.792042+03	2017-10-12	120	A	LOD-1566. Отработка	12	t	O
173	2017-10-16 09:08:08.800561+03	2017-10-14	270	A	таксомотор	10	t	O
172	2017-10-14 17:31:49.666437+03	2017-10-14	60	A	LOD-1479  доработки вечером делал  - исправлял ошибки в данных	8	t	O
171	2017-10-14 13:32:31.375629+03	2017-10-14	180	A	LOD-1479  Подготовить сервис отправки в АИС Таксомотор для отправки реестра разрешений	8	t	O
170	2017-10-13 18:10:16.932672+03	2017-10-13	60	A	отработка долга	13	t	O
174	2017-10-16 13:27:22.30394+03	2017-10-20	60	A	Нужно уйти с 17:00	3	f	O
175	2017-10-16 15:37:24.657553+03	2017-10-16	240	A	-	14	f	O
177	2017-10-17 09:41:52.131967+03	2017-10-16	480	A	отработка	8	t	O
176	2017-10-17 09:26:50.764162+03	2017-10-17	150	A	Устранение проблемы LOD-1625	13	t	O
178	2017-10-17 16:10:59.470445+03	2017-10-17	480	A	-	8	t	O
179	2017-10-17 18:08:08.428887+03	2017-10-17	60	A	LOD-1628	10	t	O
181	2017-10-18 14:11:37.294351+03	2017-10-17	60	A	Закрытие критичных обращений пользователей	17	t	O
180	2017-10-18 14:11:26.940004+03	2017-10-16	60	A	Закрытие критичных обращений пользователей	17	t	O
182	2017-10-18 16:11:08.008524+03	2017-10-18	480	A	отработка	8	t	O
184	2017-10-19 14:26:02.533562+03	2017-10-19	150	A	-	10	f	O
185	2017-10-19 16:22:22.747792+03	2017-10-19	450	A	-	8	t	O
183	2017-10-18 18:54:40.729973+03	2017-10-18	60	A	Закрытие критичных обращений пользователей	17	t	O
187	2017-10-19 19:49:19.928811+03	2017-10-19	60	A	Подготовка к показу приема заявлений по Металлам 2	5	t	O
186	2017-10-19 18:05:31.06876+03	2017-10-19	60	A	Подготовка к показу приема заявлений по Металлам	5	t	O
188	2017-10-20 08:31:31.777853+03	2017-10-20	60	A	  c 16:00	3	f	O
189	2017-10-20 14:20:18.379449+03	2017-10-19	60	A	Отработка долга	17	t	O
190	2017-10-20 16:30:20.049449+03	2017-10-20	390	A	отработка	8	t	O
191	2017-10-23 10:45:34.478385+03	2017-10-23	60	A	c 11 до 12   (с переходом на обед с 12 до 13)	8	f	O
193	2017-10-24 10:49:37.50968+03	2017-10-24	60	A	Ремонт.	16	f	O
192	2017-10-24 10:46:11.101525+03	2017-10-24	60	A	-	8	f	O
194	2017-10-24 18:02:22.13206+03	2017-10-24	60	A	Отработка долга по задаче LOD-1618	5	t	O
195	2017-10-25 12:10:17.509034+03	2017-10-25	180	A	Судебная экспертиза №2.	16	f	O
196	2017-10-25 12:17:04.647322+03	2017-10-25	240	A	Вторая половина дня.	9	f	O
199	2017-10-31 14:33:31.378809+03	2017-10-31	60	A	По личным обстоятельствам	13	f	O
198	2017-10-31 10:00:22.742408+03	2017-10-31	60	A	Ремонт.	16	f	O
197	2017-10-31 08:29:42.032422+03	2017-10-30	480	A	-	10	f	O
201	2017-11-01 08:33:54.386695+03	2017-10-31	150	A	Сопровождение показа Платные услуги МСХ, подготовка к показу Плтные услуги МПРУ Металлы	9	t	O
200	2017-10-31 20:31:16.624513+03	2017-10-31	150	A	Поддержка показа МСХ, подготовка к показу МПРУ	5	t	O
202	2017-11-02 09:27:38.916529+03	2017-11-01	90	A	регламентные работы	13	t	O
204	2017-11-08 15:06:23.071668+03	2017-11-07	60	A	Подготовка к показу ГПЗУ, Обновление МПРУ	5	t	O
203	2017-11-03 15:07:34.133689+03	2017-11-03	60	A	-	16	f	O
205	2017-11-09 13:01:27.044728+03	2017-11-09	180	A	-	10	f	O
207	2017-11-13 09:18:32.345423+03	2017-11-12	120	A	Работы по переключению продуктива на nginx	7	t	O
206	2017-11-13 08:45:42.744334+03	2017-11-12	210	A	LOD-1749	10	t	O
208	2017-11-13 14:13:39.28678+03	2017-11-13	240	A	-	12	f	O
209	2017-11-13 14:54:14.927424+03	2017-11-13	60	A	В счет ранее отработанного времени, убегал в УК	5	f	O
210	2017-11-15 09:46:43.850286+03	2017-11-14	480	A	Плохое самочувствие	15	f	O
211	2017-11-15 10:01:39.382929+03	2017-11-15	960	A	Температурил.	16	f	O
212	2017-11-16 11:30:08.57415+03	2017-11-16	1440	A	Три отпускных дня	12	t	O
227	2017-12-05 15:24:56.203001+03	2017-12-05	60	A	Привоз сантехники.	16	f	O
228	2017-12-05 15:25:18.69423+03	2017-11-29	240	A	Суд. Заседание №2.	16	f	O
229	2017-12-05 15:41:30.670828+03	2017-12-05	60	A	лечил спину	7	f	O
213	2017-11-16 15:27:58.134442+03	2017-11-16	210	D	test	1	t	O
214	2017-11-17 14:25:36.517314+03	2017-11-17	90	A	самочувствие	10	f	O
215	2017-11-17 14:53:29.479374+03	2017-11-17	120	A	по личным делам	7	f	O
216	2017-11-20 09:30:54.908805+03	2017-11-20	240	A	Внутренний экзамен в автошколе	15	f	O
217	2017-11-21 13:25:53.77163+03	2017-11-21	60	A	задержался на обеде	8	f	O
218	2017-11-21 19:07:29.732836+03	2017-11-21	60	A	Закрытие критичных обращений пользователей	17	t	O
219	2017-11-27 10:35:00.669688+03	2017-11-26	180	A	LOD-1842	10	t	O
220	2017-11-27 10:40:49.392485+03	2017-11-28	180	A	c 9:00 дo 12:00	8	f	O
221	2017-11-28 15:34:42.626688+03	2017-11-27	90	A	1 час (Минздрав)   полчаса в пятницу(упало окружение)	8	t	O
231	2017-12-06 10:14:29.43923+03	2017-12-05	120	A	вывод в продуктив автогенерации бланков разрешений и шаблонов документов	14	t	O
222	2017-11-29 09:51:42.692439+03	2017-11-21	5760	A	Листок нетрудоспособности 278 729 274 118	18	f	I
223	2017-11-29 14:28:33.257962+03	2017-11-29	240	A	-	14	f	O
224	2017-12-01 15:46:30.350304+03	2017-12-01	120	A	Самочувствие	9	f	O
225	2017-12-04 11:40:26.122657+03	2017-12-03	150	A	По задаче LOD-1842 с учетом пятницы	10	t	O
226	2017-12-04 14:31:14.727064+03	2017-12-04	60	A	лечение спины	7	f	O
230	2017-12-06 10:14:15.815006+03	2017-12-05	120	A	вывод функционала по Такси, дежурство при показе	8	t	O
232	2017-12-07 11:18:43.173961+03	2017-12-07	120	A	отгул	10	f	O
234	2017-12-07 11:19:45.097941+03	2017-12-07	60	A	лечил спину	7	f	O
233	2017-12-07 11:19:33.533021+03	2017-12-06	60	A	лечил спину	7	f	O
235	2017-12-11 15:57:50.552718+03	2017-12-08	480	A	По семейным обстоятельствам.	19	f	O
236	2017-12-11 15:58:29.96628+03	2017-12-07	180	A	По семейным обстоятельствам.	19	f	O
237	2017-12-11 16:57:13.729639+03	2017-12-12	180	A	с 14 до 17 в Ярославль на суд	8	f	O
238	2017-12-12 13:06:23.05097+03	2017-12-12	240	A	-	12	f	O
239	2017-12-12 17:57:06.447081+03	2017-12-11	120	A	всего отгул получился 2.5 часа (работал с 12-17:30), сегодня отработал 30 мин.	13	f	O
240	2017-12-12 19:00:14.856957+03	2017-12-13	480	A	По семейным обстоятельствам	19	f	O
241	2017-12-14 09:10:17.132305+03	2017-12-13	240	A	-	14	f	O
242	2017-12-14 10:25:50.620922+03	2017-12-12	2880	A	Болел. Отравление с симптомами характерными для простуды.	15	f	I
243	2017-12-14 10:26:43.899158+03	2017-12-20	480	A	Сдача экзамена в ГАИ.	15	f	O
244	2017-12-15 12:24:10.949907+03	2017-12-15	240	A	Загрустил	9	f	O
245	2017-12-15 14:46:36.915968+03	2017-12-15	60	A	Ремонт (Утро   Обед).	16	f	O
246	2017-12-18 10:34:55.047053+03	2017-12-18	90	A	поход на отечественную медицину	14	f	O
247	2017-12-19 14:15:24.240174+03	2017-12-19	60	A	расширил обед	8	f	O
248	2017-12-20 11:08:05.351117+03	2017-12-19	90	A	Алкоголь, 100 услуг, тестирование	7	t	O
249	2017-12-22 08:45:28.868158+03	2017-12-21	180	A	-	8	f	O
250	2017-12-25 14:37:50.761951+03	2017-12-20	240	A	Орешкиным было назначено совещание по услуге КУРТ в 21.30, ушел с рабочего места в 23.00.	19	t	O
251	2017-12-25 14:42:01.610393+03	2017-12-18	180	A	Орешкин назначил совещание по процессу КУРТ в 19.30. Во время совещания были небольшие паузы, так как он отходил на другие совещания. Я завершил рабочий день в 22.00.	19	t	O
252	2017-12-26 09:18:09.488075+03	2017-12-25	120	A	LOD-1937	10	t	O
253	2017-12-26 09:19:44.706199+03	2017-12-24	90	A	Консультации и помощь в тестировании алкоголя 100 услуг	7	t	O
254	2017-12-26 14:40:27.627218+03	2017-12-25	480	A	Ремонт. Кухня.	16	f	O
255	2017-12-27 07:59:14.317719+03	2017-12-26	120	A	ЗОСТ	12	t	O
256	2017-12-27 10:43:06.388803+03	2017-12-26	120	A	LOD-1864	8	t	O
257	2017-12-27 12:28:17.201835+03	2017-12-27	150	A	Суд. Заседание №3.	16	f	O
258	2017-12-27 14:56:20.985577+03	2017-12-28	480	A	-	17	f	O
260	2017-12-28 07:37:45.922124+03	2017-12-27	240	A	похождения против бесплатной медицины - 2 (Возмездие)	14	f	O
259	2017-12-27 18:58:19.205081+03	2017-12-26	60	A	Задержался на совещание с Кураповой, в связи с чем рабочий день сместился на  1 час.	19	t	O
261	2017-12-28 09:31:40.912321+03	2017-12-27	240	A	LOD-1864	8	t	O
262	2017-12-28 13:29:38.130253+03	2017-12-28	210	A	Ремонт. Потолок.	16	f	O
264	2017-12-29 17:35:54.416304+03	2017-12-29	60	A	ЗОСТ	12	t	O
263	2017-12-29 17:32:12.242629+03	2017-12-29	60	A	Вывод доработок по МПРУ Платные услуги и Прием заявлений по МПРУ	5	t	O
265	2018-01-07 18:10:03.87527+03	2018-01-07	120	A	поиск заявки по заявке Галактионовой по заявке Титова, который отправил заявку с портала, но которая почему-то не пришла в ЛОД. Прогрузка номеров заявок в РЛДД по такси, стройке, гпзу	14	t	O
266	2018-01-09 14:19:15.438265+03	2018-01-09	60	A	задержался на обеде	8	f	O
267	2018-01-09 18:05:47.280889+03	2018-01-09	60	A	Отработка долга (работал с 8.00)	17	t	O
268	2018-01-11 12:31:00.022844+03	2018-01-11	180	A	по состоянию здоровья	10	f	O
269	2018-01-11 13:00:15.667255+03	2018-01-11	60	A	-	12	f	O
270	2018-01-11 19:24:05.858158+03	2018-01-11	90	A	текущие задачи	10	t	O
271	2018-01-12 10:28:27.476143+03	2018-01-11	240	A	Плохое самочувствие	9	f	O
272	2018-01-16 08:25:42.020125+03	2018-01-16	60	A	Два раза по 30 мин 15.01 и 16.01	9	t	O
273	2018-01-16 14:46:47.589106+03	2018-01-16	60	A	Обед  	16	f	O
274	2018-01-18 09:04:06.678907+03	2018-01-17	240	A	Подготовка к показу КУРТ 18.01 с 18-00 до 22-00	9	t	O
275	2018-01-18 09:56:07.936329+03	2018-01-17	240	A	подготовка к показу КУРТОВ	5	t	O
276	2018-01-18 18:43:02.324954+03	2018-01-18	480	A	бесплатная медицина и сгонять за документами	14	f	O
277	2018-01-19 18:13:55.45786+03	2018-01-19	60	A	осмотр машины	7	f	O
278	2018-01-22 18:57:29.310114+03	2018-01-22	60	A	Работа над верхнеуровневым планом с 18 до 19	9	t	O
280	2018-01-25 09:04:48.745571+03	2018-01-24	120	A	Решение вопроса о выводе формы ОКС	9	t	O
279	2018-01-24 22:38:57.975479+03	2018-01-24	150	A	по семейным обст	10	f	O
282	2018-01-25 15:50:09.136722+03	2018-01-25	210	A	Вывод функционала	13	t	O
283	2018-01-26 09:09:08.384863+03	2018-01-26	240	A	Вторая половина дня. Отдых с семьей	9	f	O
284	2018-01-26 17:59:25.425473+03	2018-01-26	60	A	Исправление ошибок минстрой	13	t	O
285	2018-01-30 22:00:14.517337+03	2018-01-30	120	A	подготовка выгрузки продлений и их отказов по стройке с параметрами, поиск заявки по плачу таксистов, потому что МФЦ не видит результата их доблестного труда	14	t	O
288	2018-01-31 10:10:22.101729+03	2018-01-30	120	A	Работа с документами процесса Возобновления, доп. настройки процесса. Утром пришел к 8.15, ушел в ~18.20. Чуть больше часа доделывал из дома. 	15	t	O
286	2018-01-31 10:00:25.958757+03	2018-01-29	90	A	Работал из дома, занимался подтягиванием заявки в ЛК   настройкой результатов для ЛК.	15	t	O
291	2018-02-01 08:16:31.364354+03	2018-01-31	60	A	поиск заявок Тевикова, добавление учетной записи, которая в ночи понадобилась новому замминистра стройки, поиск КУРТов и ЗОСТов	14	t	O
290	2018-01-31 22:23:02.158027+03	2018-01-31	210	A	ЛК алкоголь с 19 до 22:30	8	t	O
289	2018-01-31 20:58:30.55955+03	2018-01-30	90	A	ЛК алкоголь	8	t	O
297	2018-02-06 08:35:04.843301+03	2018-02-05	60	A	Подзадача\tLOD-2083	10	t	O
292	2018-02-01 09:49:53.329903+03	2018-01-26	1440	D	семейные обстоятельства	10	f	O
293	2018-02-01 12:11:52.691376+03	2018-01-31	90	A	Работал из дома. Разбирался с функцией рендеринга для документа о положительном решении на ЛК, внес правки. Анализировал ошибку связки процесса с лицензией, доработал сохранение.	15	t	O
294	2018-02-01 22:11:20.011293+03	2018-02-01	90	A	переделал вывод мест деятельности в контексте решений на алко-ЛК, подготовка ежемесячного отчета по очным заявкам, разбор ошибок отправки в ЛОД	14	t	O
295	2018-02-02 11:37:01.776369+03	2018-02-02	120	A	Сидел с дочкой	7	f	O
296	2018-02-05 09:07:28.526534+03	2018-02-04	60	A	разбирался со статусами РЛДД на ЛК	8	t	O
298	2018-02-06 19:37:27.924731+03	2018-02-06	150	A	Подзадача LOD-2083	10	t	O
299	2018-02-12 11:26:52.377545+03	2018-02-12	270	A	По семейным обстаятельствам с 12-30 до 18-00	9	f	O
300	2018-02-13 09:30:45.97786+03	2018-02-12	480	A	семейные обстоятельства	10	f	O
301	2018-02-13 14:42:01.992369+03	2018-02-13	60	A	По семейным обстоятельствам	13	f	O
302	2018-02-14 10:20:31.400443+03	2018-02-12	2880	A	Немного полечился, чтобы не разболеться.	12	f	I
304	2018-02-15 09:40:24.788915+03	2018-02-14	60	A	Решение заявок от Кати и Тевикова	14	t	O
303	2018-02-15 09:39:46.083313+03	2018-02-14	90	A	текущие задачи	10	t	O
308	2018-02-19 12:33:46.969504+03	2018-02-16	60	A	Работал без перерыва на обед.	12	t	O
306	2018-02-16 13:55:34.069743+03	2018-02-15	60	A	Совещание по текущему статусу задач	7	t	O
305	2018-02-15 18:47:25.542917+03	2018-02-15	60	A	отчет для нашей "любимейшей", чтоб ей икалось)))	14	t	O
307	2018-02-16 17:55:14.549042+03	2018-02-16	60	A	по 30 мин. утром 15 и 16.02	9	t	O
309	2018-02-19 20:16:28.950527+03	2018-02-19	180	A	текущие задачи	10	t	O
312	2018-02-21 08:29:01.723414+03	2018-02-20	480	A	охотился за головой...гипсовой)))	14	f	O
311	2018-02-20 18:40:58.171286+03	2018-02-20	60	A	текущие задачи	10	t	O
310	2018-02-20 18:29:56.458961+03	2018-02-20	120	A	доделка функционала перед отпуском	13	t	O
313	2018-02-21 17:45:20.875234+03	2018-02-20	60	A	Переработки два раза по 30 мин. утром 19 и 20 февраля с 8-30	9	t	O
315	2018-02-25 22:20:54.664499+03	2018-02-25	180	A	LOD-2204	14	t	O
314	2018-02-24 23:40:02.130301+03	2018-02-24	420	A	LOD-2186, LOD-2195, LOD-2219	14	t	O
316	2018-02-26 17:49:31.535009+03	2018-02-26	60	A	Отработка долгов, работал с 8 часов	17	t	O
317	2018-02-27 18:02:50.125993+03	2018-02-27	60	D	текущие (LOD-2168)	10	f	O
319	2018-02-28 08:55:36.108782+03	2018-02-27	300	A	охота за головами-2	14	f	O
318	2018-02-28 08:37:56.768692+03	2018-02-28	90	A	3 дня по 30 минут  утром. 26, 27, 28 февраля. Погашение отгула.	9	t	O
320	2018-02-28 09:28:09.474792+03	2018-02-27	60	A	Доработки по API	10	t	O
321	2018-02-28 18:08:12.372864+03	2018-02-28	60	A	отработка долгов. Работал с 8.00	17	t	O
322	2018-02-28 21:52:10.51505+03	2018-02-28	120	A	LOD-2180, LOD-2235	14	t	O
324	2018-03-02 08:29:02.126479+03	2018-03-01	60	A	Отработка долгов. Работал с 8.00	17	t	O
323	2018-03-01 22:53:49.43759+03	2018-03-01	180	A	возврат заявки ЗОСТ, переотправка исправленных документов Такси, LOD-2218	14	t	O
325	2018-03-02 09:17:35.583483+03	2018-03-02	60	D	утром с 8:40	8	f	O
327	2018-03-04 20:17:36.930641+03	2018-03-04	180	A	LOD-2256 (02.03), LOD-2252 (04.03)	14	t	O
326	2018-03-02 18:07:16.01483+03	2018-03-02	60	A	текущие задачи	10	t	O
328	2018-03-05 15:27:58.222533+03	2018-03-02	60	A	Отработка долгов. В пятницу с 8 работал	17	t	O
330	2018-03-05 21:52:53.815097+03	2018-03-05	60	A	LOD-2270	14	t	O
329	2018-03-05 19:57:04.65864+03	2018-03-05	120	A	LOD-2261 поиск и устранение, проверка	10	t	O
331	2018-03-06 18:15:43.531023+03	2018-03-06	60	A	LOD-2199	10	t	O
332	2018-03-07 11:32:01.88015+03	2018-03-07	180	A	с 13 до 16 (раз короткий день)	8	f	O
333	2018-03-07 14:54:47.19872+03	2018-03-07	60	A	Утро 06 и 07.03.2018 по 30 мин утром с 8.30	9	t	O
334	2018-03-08 12:37:07.337782+03	2018-03-07	180	A	Отработка долгов. Работал с 6.30 до 17.30	17	t	O
335	2018-03-12 16:57:19.138171+03	2018-03-12	480	A	Работа во время отпуска	7	t	O
336	2018-03-14 09:08:55.50641+03	2018-03-13	120	A	Выход на работу во время отпуска	7	t	O
337	2018-03-14 10:29:50.913962+03	2018-03-14	60	A	-	12	f	O
339	2018-03-15 09:10:03.771955+03	2018-03-15	60	A	-	10	f	O
340	2018-03-15 09:47:20.904818+03	2018-03-15	420	A	По причине плохого самочувствия(высокая температура)	9	f	O
338	2018-03-14 15:39:52.434866+03	2018-03-14	360	D	Работа из отпуска	7	f	O
341	2018-03-16 09:55:36.671597+03	2018-03-14	360	A	Работа из отпуска	7	t	O
342	2018-03-16 09:56:04.250483+03	2018-03-15	480	A	Работа из отпуска	7	t	O
343	2018-03-16 09:56:40.724819+03	2018-03-16	480	A	Работа из отпуска	7	t	O
344	2018-03-16 11:47:36.809371+03	2018-03-16	300	A	с 12 до конча рабочего дня, по причине плохого самочувствия.	9	f	O
345	2018-03-16 14:38:33.963004+03	2018-03-16	60	A	Поликлиника с 14-15	5	f	O
347	2018-03-19 08:14:58.26291+03	2018-03-15	2880	A	14 работал. 15,16 не более 3х часов	8	f	I
349	2018-03-19 09:04:41.375689+03	2018-03-16	1440	A	-	10	f	I
348	2018-03-19 08:16:47.542537+03	2018-03-15	150	A	немного поработал 15 и 16 	8	t	O
346	2018-03-17 20:00:10.886201+03	2018-03-17	300	A	Закрытие критичных обращений пользователей	17	t	O
350	2018-03-19 09:28:35.654032+03	2018-03-19	180	A	По состоянию здоровья	10	f	O
351	2018-03-19 11:01:47.933936+03	2018-03-15	120	A	Требовалось отъехать в суд	19	f	O
352	2018-03-19 13:40:40.055661+03	2018-03-19	480	A	Работа из отпуска	7	t	O
354	2018-03-21 12:47:02.403725+03	2018-03-21	480	A	Работа из отпуска	7	t	O
353	2018-03-21 12:46:52.688948+03	2018-03-20	480	A	Работа из отпуска	7	t	O
355	2018-03-21 21:40:34.284626+03	2018-03-21	150	A	сборка отчетов по алко-металлам и медицине	14	t	O
356	2018-03-22 09:52:07.95663+03	2018-03-22	480	A	Работа в отпуске	7	t	O
358	2018-03-26 09:20:43.896008+03	2018-03-26	5760	A	-	10	f	I
357	2018-03-25 13:21:36.058539+03	2018-03-25	240	A	Закрытие критичных обращений пользователей	17	t	O
359	2018-03-26 10:26:41.945224+03	2018-03-23	480	A	Работа из отпуска	7	t	O
378	2018-04-06 16:35:51.329532+03	2018-04-03	1440	A	-	18	f	I
377	2018-04-06 14:12:02.773323+03	2018-04-06	120	A	По 30 мин утром 18 и 20, один час обеда 18-го	9	t	O
376	2018-04-06 12:10:48.480911+03	2018-04-06	60	A	-	10	f	O
375	2018-04-05 19:00:03.696711+03	2018-04-05	60	A	Инвест соглашения, консультация Владислава	5	t	O
369	2018-04-02 13:00:45.142513+03	2018-04-02	240	A	с 8 до 12	8	f	O
371	2018-04-03 09:21:37.489524+03	2018-04-02	60	A	подготовка выгрузки реестра по запросу Тевикова	14	t	O
370	2018-04-02 19:04:26.86183+03	2018-04-02	90	A	LOD-2351  API: инвест. соглашение	10	t	O
365	2018-04-02 09:40:00.781232+03	2018-03-31	180	A	Вынужденная работа без обеда и совещание вне рабочее время с сотрудниками МТДИ	9	t	O
368	2018-04-02 09:44:43.234699+03	2018-03-29	90	A	отработка отгула за 16 апреля	13	t	O
367	2018-04-02 09:44:22.290722+03	2018-03-30	60	A	отработка отгула за 16 апреля	13	t	O
372	2018-04-03 18:02:15.968393+03	2018-04-03	120	A	02-03.04 утром с 8-30, 03.04 - доп. час вместо обеда	9	t	O
364	2018-03-30 16:48:14.097913+03	2018-03-29	120	A	вечерние разборы заявок с Катей по поручению Шефа, обсуждение с Тевиковым проблем реализации гибридного результата	14	t	O
363	2018-03-28 18:05:29.486278+03	2018-03-28	60	A	АПИ минстр	10	t	O
362	2018-03-28 07:46:28.4734+03	2018-03-27	180	A	покорение МФЦ	14	f	O
361	2018-03-26 21:51:56.073603+03	2018-03-26	90	A	Закрытие критичных обращений пользователей, отчет о недоступности системы	17	t	O
360	2018-03-26 18:04:29.345987+03	2018-03-26	60	A	API минстрой	10	t	O
373	2018-04-04 13:46:31.122071+03	2018-04-04	180	A	вынужден уехать по семейным обстоятельствам	8	f	O
374	2018-04-04 15:21:38.753811+03	2018-04-04	120	A	успел решить проблемы за час	8	t	O
387	2018-04-09 11:02:55.614342+03	2018-04-05	480	A	Отпуск	7	f	O
386	2018-04-09 11:02:52.250394+03	2018-04-04	480	A	Отпуск	7	f	O
385	2018-04-09 11:02:49.121885+03	2018-04-03	480	A	Отпуск	7	f	O
384	2018-04-09 11:02:45.754352+03	2018-04-02	480	A	Отпуск	7	f	O
383	2018-04-09 11:02:39.000305+03	2018-03-30	480	A	Отпуск	7	f	O
382	2018-04-09 11:02:35.318347+03	2018-03-29	480	A	Отпуск	7	f	O
381	2018-04-09 11:02:31.651779+03	2018-03-28	480	A	Отпуск	7	f	O
380	2018-04-09 11:02:26.612642+03	2018-03-27	480	A	Отпуск	7	f	O
379	2018-04-09 11:02:12.339087+03	2018-03-26	360	A	Ушел в отпуск	7	f	O
388	2018-04-09 11:02:59.474098+03	2018-04-06	480	A	Отпуск	7	f	O
389	2018-04-09 15:23:36.799338+03	2018-04-09	60	A	лечил зубы	7	f	O
392	2018-04-12 18:22:50.310335+03	2018-04-12	60	A	 LOD-2374 - Разработать систему оповещения о состоянии системы автомежвед запросов	10	t	O
391	2018-04-12 10:27:17.918+03	2018-04-12	60	A	-	5	f	O
390	2018-04-12 10:27:07.611419+03	2018-03-29	60	A	-	5	f	O
393	2018-04-13 09:25:47.574316+03	2018-04-13	270	A	по причине: поездка в больницу в Ярославль 	8	f	O
395	2018-04-14 22:02:04.768878+03	2018-04-14	210	A	правка шаблонов приказов для фармы и наркотиков (срок заявки - понедельник)	17	t	O
394	2018-04-14 10:55:39.518724+03	2018-04-14	90	A	13.04 -  подготовка выгрузки для Кати и Колывагиной, 14.04 - помощь коллегам из МФЦ по отправке заявки по алкоголю	14	t	O
397	2018-04-17 14:04:05.306123+03	2018-04-17	240	A	отгул по заявлению	13	f	O
396	2018-04-17 14:03:53.599275+03	2018-04-16	480	A	отгул по заявлению	13	f	O
398	2018-04-18 10:21:59.201767+03	2018-04-18	240	A	в связи с поездкой в Областную Больницу в Ярославль	8	f	O
399	2018-04-18 17:57:22.251897+03	2018-04-18	60	A	отработка долга	13	t	O
400	2018-04-19 14:02:58.402065+03	2018-04-19	180	A	в связи с плохим самочувствием	13	f	O
401	2018-04-19 18:15:15.75334+03	2018-04-19	60	A	LOD-2497 Передача справочника ОПФ через API	10	t	O
402	2018-04-20 10:28:31.871226+03	2018-04-20	90	A	со смещением рабочего графика с 9 до 18	8	f	O
403	2018-04-20 11:01:31.689887+03	2018-04-20	60	A	на процедуры	5	f	O
404	2018-04-23 09:31:45.721032+03	2018-04-23	60	A	землеустройство в 10	8	f	O
405	2018-04-24 17:58:32.714078+03	2018-04-24	480	A	Работал в отпуск 	17	t	O
406	2018-04-24 19:24:00.038765+03	2018-04-24	120	A	Работа над текущей задачей LOD-2508	10	t	O
407	2018-04-26 08:31:14.507658+03	2018-04-25	60	A	Исправление ошибки с запросом справочников из ФСРАР	7	t	O
408	2018-04-26 08:41:11.466054+03	2018-04-24	480	A	отгул с посещением лечебных учреждений	14	f	O
409	2018-04-26 10:30:02.177969+03	2018-04-25	60	A	исправление ошибки при подписании	13	t	O
410	2018-04-27 17:17:07.573631+03	2018-04-27	90	A	Текущая задача LOD-2521, вывод и отладка рефакторинга ИСОГД.	10	t	O
411	2018-04-28 18:06:47.172297+03	2018-04-28	180	A	27 и 28.04, работа в сокращенные дни на 1.5 часа больше	7	t	O
413	2018-05-04 10:29:01.212326+03	2018-05-03	480	A	-	17	f	O
412	2018-05-04 10:28:52.072604+03	2018-05-04	60	A	-	17	f	O
415	2018-05-07 17:48:31.273239+03	2018-05-07	60	A	Борьба с РТК	7	f	O
414	2018-05-06 10:20:53.096894+03	2018-05-06	60	A	отправка статусов по заявкам в РЛДД (Павлов прислал список заявок, где нет результирующих статусов - отмененные по причине отзыва заявления в ЛОД)	14	t	O
416	2018-05-08 17:34:01.112704+03	2018-05-08	60	A	1 час	7	f	O
418	2018-05-10 09:58:20.506142+03	2018-05-08	60	A	Отработка долга	12	t	O
417	2018-05-10 09:57:32.930121+03	2018-05-03	960	A	Два отпускных дня	12	f	O
419	2018-05-10 14:09:30.617145+03	2018-05-10	150	A	-	16	f	O
420	2018-05-10 14:27:18.644886+03	2018-05-10	60	A	уезжал в 9:15	8	f	O
421	2018-05-14 09:57:11.245294+03	2018-05-07	4320	A	Больничный	13	f	I
\.


--
-- Name: overwork_overs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('overwork_overs_id_seq', 421, true);


--
-- Data for Name: overwork_person; Type: TABLE DATA; Schema: public; Owner: test
--

COPY overwork_person (id, name, is_manager, login, email) FROM stdin;
3	Станислав Тихомиров	f	tikhomirovsvl	TikhomirovSVl@mosreg.ru
5	Облеухов Антон Алексеевич	f	ObleukhovAA	ObleukhovAA@mosreg.ru
1	Руководитель 	f	manager	belovmm@mosreg.ru
7	Михаил Белов	t	BelovMM	BelovMM@mosreg.ru
8	Миронов Юрий Юрьевич	f	MironovIUIU	MironovIUIU@mosreg.ru
9	Андрей Лаврухин	f	lavruhinae	lavruhinae@mosreg.ru
10	Добрынин Сергей Алексеевич	f	DobryninSA	DobryninSA@mosreg.ru
11	Кабанов Ренат Евгеньевич	f	KabanovRE	KabanovRE@mosreg.ru
12	Павел Ларионов	f	Larionov	larionovpo@mosreg.ru
13	Осипков Андрей Сергеевич	f	OsipkovAS	OsipkovAS@mosreg.ru
15	Роман Осокин	f	OsokinRL	OsokinRL@mosreg.ru
16	Белов Андрей Владимирович	f	BelovANVlA	BelovANVlA@mosreg.ru
17	Роман Журавлев	f	zhuravlevrv	zhuravlevrv@mosreg.ru
18	Илья Лебедев	f	lebedevim	lebedevim@mosreg.ru
14	Илья Андреевич Коновалов	f	KonovalovIA	KonovalovIA@mosreg.ru
19	Влад Рожков	f	RozhkovVV	RozhkovVV@mosreg.ru
\.


--
-- Name: overwork_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: test
--

SELECT pg_catalog.setval('overwork_person_id_seq', 19, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: overwork_overs overwork_overs_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY overwork_overs
    ADD CONSTRAINT overwork_overs_pkey PRIMARY KEY (id);


--
-- Name: overwork_person overwork_person_pkey; Type: CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY overwork_person
    ADD CONSTRAINT overwork_person_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_user_groups_group_id_97559544 ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX django_session_expire_date_a5c62663 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: overwork_overs_person_id_39734302; Type: INDEX; Schema: public; Owner: test
--

CREATE INDEX overwork_overs_person_id_39734302 ON overwork_overs USING btree (person_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: overwork_overs overwork_overs_person_id_39734302_fk_overwork_person_id; Type: FK CONSTRAINT; Schema: public; Owner: test
--

ALTER TABLE ONLY overwork_overs
    ADD CONSTRAINT overwork_overs_person_id_39734302_fk_overwork_person_id FOREIGN KEY (person_id) REFERENCES overwork_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

